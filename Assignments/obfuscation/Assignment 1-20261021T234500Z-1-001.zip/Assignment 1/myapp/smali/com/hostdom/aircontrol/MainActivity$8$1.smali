.class Lcom/hostdom/aircontrol/MainActivity$8$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/hostdom/aircontrol/MainActivity$8;->onJsAlert(Landroid/webkit/WebView;Ljava/lang/String;Ljava/lang/String;Landroid/webkit/JsResult;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/webkit/JsResult;

.field final synthetic b:Lcom/hostdom/aircontrol/MainActivity$8;


# direct methods
.method constructor <init>(Lcom/hostdom/aircontrol/MainActivity$8;Landroid/webkit/JsResult;)V
    .locals 0

    iput-object p1, p0, Lcom/hostdom/aircontrol/MainActivity$8$1;->b:Lcom/hostdom/aircontrol/MainActivity$8;

    iput-object p2, p0, Lcom/hostdom/aircontrol/MainActivity$8$1;->a:Landroid/webkit/JsResult;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 0

    iget-object p1, p0, Lcom/hostdom/aircontrol/MainActivity$8$1;->a:Landroid/webkit/JsResult;

    invoke-virtual {p1}, Landroid/webkit/JsResult;->confirm()V

    return-void
.end method
