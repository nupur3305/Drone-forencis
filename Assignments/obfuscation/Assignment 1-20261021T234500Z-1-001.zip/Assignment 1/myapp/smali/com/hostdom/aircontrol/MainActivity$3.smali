.class Lcom/hostdom/aircontrol/MainActivity$3;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/hostdom/aircontrol/MainActivity;->p()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/hostdom/aircontrol/MainActivity;


# direct methods
.method constructor <init>(Lcom/hostdom/aircontrol/MainActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/hostdom/aircontrol/MainActivity$3;->a:Lcom/hostdom/aircontrol/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 0

    new-instance p1, Landroid/content/Intent;

    const-string p2, "android.settings.LOCATION_SOURCE_SETTINGS"

    invoke-direct {p1, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    iget-object p2, p0, Lcom/hostdom/aircontrol/MainActivity$3;->a:Lcom/hostdom/aircontrol/MainActivity;

    iget-object p2, p2, Lcom/hostdom/aircontrol/MainActivity;->s:Landroid/content/Context;

    invoke-virtual {p2, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method
