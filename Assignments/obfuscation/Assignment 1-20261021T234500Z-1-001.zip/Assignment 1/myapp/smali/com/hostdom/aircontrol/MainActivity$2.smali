.class Lcom/hostdom/aircontrol/MainActivity$2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/hostdom/aircontrol/MainActivity;->n()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/hostdom/aircontrol/MainActivity;


# direct methods
.method constructor <init>(Lcom/hostdom/aircontrol/MainActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/hostdom/aircontrol/MainActivity$2;->a:Lcom/hostdom/aircontrol/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 0

    iget-object p1, p0, Lcom/hostdom/aircontrol/MainActivity$2;->a:Lcom/hostdom/aircontrol/MainActivity;

    invoke-virtual {p1}, Lcom/hostdom/aircontrol/MainActivity;->finish()V

    return-void
.end method
