.class Lcom/hostdom/aircontrol/MainActivity$11;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/support/v4/widget/SwipeRefreshLayout$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/hostdom/aircontrol/MainActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/hostdom/aircontrol/MainActivity;


# direct methods
.method constructor <init>(Lcom/hostdom/aircontrol/MainActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/hostdom/aircontrol/MainActivity$11;->a:Lcom/hostdom/aircontrol/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()V
    .locals 1

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$11;->a:Lcom/hostdom/aircontrol/MainActivity;

    iget-object v0, v0, Lcom/hostdom/aircontrol/MainActivity;->m:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->reload()V

    return-void
.end method
