.class Lcom/hostdom/aircontrol/MainActivity$9;
.super Landroid/webkit/WebViewClient;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/hostdom/aircontrol/MainActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/Boolean;

.field final synthetic b:Lcom/hostdom/aircontrol/MainActivity;


# direct methods
.method constructor <init>(Lcom/hostdom/aircontrol/MainActivity;Ljava/lang/Boolean;)V
    .locals 0

    iput-object p1, p0, Lcom/hostdom/aircontrol/MainActivity$9;->b:Lcom/hostdom/aircontrol/MainActivity;

    iput-object p2, p0, Lcom/hostdom/aircontrol/MainActivity$9;->a:Ljava/lang/Boolean;

    invoke-direct {p0}, Landroid/webkit/WebViewClient;-><init>()V

    return-void
.end method


# virtual methods
.method a(Ljava/lang/String;)Ljava/lang/Boolean;
    .locals 3

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$9;->a:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$9;->b:Lcom/hostdom/aircontrol/MainActivity;

    invoke-static {v0, p1}, Lcom/hostdom/aircontrol/MainActivity;->b(Lcom/hostdom/aircontrol/MainActivity;Ljava/lang/String;)Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1

    :cond_0
    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$9;->b:Lcom/hostdom/aircontrol/MainActivity;

    invoke-static {v0, p1}, Lcom/hostdom/aircontrol/MainActivity;->b(Lcom/hostdom/aircontrol/MainActivity;Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_2

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$9;->b:Lcom/hostdom/aircontrol/MainActivity;

    iget-object v0, v0, Lcom/hostdom/aircontrol/MainActivity;->p:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 p1, 0x0

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1

    :cond_1
    new-instance v0, Landroid/content/Intent;

    const-string v2, "android.intent.action.VIEW"

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-direct {v0, v2, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    iget-object p1, p0, Lcom/hostdom/aircontrol/MainActivity$9;->b:Lcom/hostdom/aircontrol/MainActivity;

    invoke-virtual {p1, v0}, Lcom/hostdom/aircontrol/MainActivity;->startActivity(Landroid/content/Intent;)V

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1

    :cond_2
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

.method public onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V
    .locals 2

    invoke-static {}, Landroid/webkit/CookieSyncManager;->getInstance()Landroid/webkit/CookieSyncManager;

    move-result-object v0

    invoke-virtual {v0}, Landroid/webkit/CookieSyncManager;->sync()V

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$9;->b:Lcom/hostdom/aircontrol/MainActivity;

    invoke-virtual {v0}, Lcom/hostdom/aircontrol/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f040010

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$9;->b:Lcom/hostdom/aircontrol/MainActivity;

    iget-object v0, v0, Lcom/hostdom/aircontrol/MainActivity;->v:Landroid/support/v7/widget/Toolbar;

    invoke-virtual {p1}, Landroid/webkit/WebView;->getTitle()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/support/v7/widget/Toolbar;->setTitle(Ljava/lang/CharSequence;)V

    :cond_0
    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V

    return-void
.end method

.method public onReceivedError(Landroid/webkit/WebView;ILjava/lang/String;Ljava/lang/String;)V
    .locals 2

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$9;->b:Lcom/hostdom/aircontrol/MainActivity;

    invoke-virtual {v0}, Lcom/hostdom/aircontrol/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f04001a

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$9;->b:Lcom/hostdom/aircontrol/MainActivity;

    invoke-virtual {v0}, Lcom/hostdom/aircontrol/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 p3, 0x0

    invoke-static {v0, p2, p3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p2

    invoke-virtual {p2}, Landroid/widget/Toast;->show()V

    :cond_0
    const-string p2, "file:///android_asset/404r.html"

    invoke-virtual {p1, p2}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public onReceivedSslError(Landroid/webkit/WebView;Landroid/webkit/SslErrorHandler;Landroid/net/http/SslError;)V
    .locals 2

    iget-object p1, p0, Lcom/hostdom/aircontrol/MainActivity$9;->b:Lcom/hostdom/aircontrol/MainActivity;

    invoke-virtual {p1}, Lcom/hostdom/aircontrol/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v0, 0x7f04001a

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/hostdom/aircontrol/MainActivity$9;->b:Lcom/hostdom/aircontrol/MainActivity;

    invoke-virtual {p1}, Lcom/hostdom/aircontrol/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p3}, Landroid/net/http/SslError;->getPrimaryError()I

    move-result v0

    const/4 v1, 0x0

    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_0
    new-instance p1, Landroid/app/AlertDialog$Builder;

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$9;->b:Lcom/hostdom/aircontrol/MainActivity;

    invoke-direct {p1, v0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    const-string v0, "SSL Certificate error."

    invoke-virtual {p3}, Landroid/net/http/SslError;->getPrimaryError()I

    move-result p3

    packed-switch p3, :pswitch_data_0

    goto :goto_0

    :pswitch_0
    const-string v0, "The date of the certificate is invalid"

    goto :goto_0

    :pswitch_1
    const-string v0, "The certificate authority is not trusted."

    goto :goto_0

    :pswitch_2
    const-string v0, "The certificate hostname mismatch."

    goto :goto_0

    :pswitch_3
    const-string v0, "The certificate has expired."

    goto :goto_0

    :pswitch_4
    const-string v0, "The certificate is not yet valid."

    :goto_0
    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " Do you want to continue anyway?"

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const-string v0, "SSL Certificate Error"

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog;->setTitle(Ljava/lang/CharSequence;)V

    invoke-virtual {p1, p3}, Landroid/app/AlertDialog;->setMessage(Ljava/lang/CharSequence;)V

    const/4 p3, -0x1

    const-string v0, "OK, Continue"

    new-instance v1, Lcom/hostdom/aircontrol/MainActivity$9$1;

    invoke-direct {v1, p0, p2}, Lcom/hostdom/aircontrol/MainActivity$9$1;-><init>(Lcom/hostdom/aircontrol/MainActivity$9;Landroid/webkit/SslErrorHandler;)V

    invoke-virtual {p1, p3, v0, v1}, Landroid/app/AlertDialog;->setButton(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)V

    const/4 p3, -0x2

    const-string v0, "Cancel"

    new-instance v1, Lcom/hostdom/aircontrol/MainActivity$9$2;

    invoke-direct {v1, p0, p2}, Lcom/hostdom/aircontrol/MainActivity$9$2;-><init>(Lcom/hostdom/aircontrol/MainActivity$9;Landroid/webkit/SslErrorHandler;)V

    invoke-virtual {p1, p3, v0, v1}, Landroid/app/AlertDialog;->setButton(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)V

    invoke-virtual {p1}, Landroid/app/AlertDialog;->show()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z
    .locals 1

    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z

    invoke-virtual {p0, p2}, Lcom/hostdom/aircontrol/MainActivity$9;->a(Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    invoke-virtual {p1, p2}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    const/4 p1, 0x0

    return p1
.end method
