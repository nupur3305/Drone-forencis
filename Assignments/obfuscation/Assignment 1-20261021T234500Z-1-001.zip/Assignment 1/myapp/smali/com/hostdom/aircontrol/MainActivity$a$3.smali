.class Lcom/hostdom/aircontrol/MainActivity$a$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/hostdom/aircontrol/MainActivity$a;->keepScreenOn(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Z

.field final synthetic b:Lcom/hostdom/aircontrol/MainActivity$a;


# direct methods
.method constructor <init>(Lcom/hostdom/aircontrol/MainActivity$a;Z)V
    .locals 0

    iput-object p1, p0, Lcom/hostdom/aircontrol/MainActivity$a$3;->b:Lcom/hostdom/aircontrol/MainActivity$a;

    iput-boolean p2, p0, Lcom/hostdom/aircontrol/MainActivity$a$3;->a:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$a$3;->b:Lcom/hostdom/aircontrol/MainActivity$a;

    iget-object v0, v0, Lcom/hostdom/aircontrol/MainActivity$a;->b:Lcom/hostdom/aircontrol/MainActivity;

    iget-object v0, v0, Lcom/hostdom/aircontrol/MainActivity;->m:Landroid/webkit/WebView;

    iget-boolean v1, p0, Lcom/hostdom/aircontrol/MainActivity$a$3;->a:Z

    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setKeepScreenOn(Z)V

    return-void
.end method
