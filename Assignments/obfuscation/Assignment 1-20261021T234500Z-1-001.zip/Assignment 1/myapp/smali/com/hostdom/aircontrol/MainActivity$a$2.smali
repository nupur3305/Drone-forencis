.class Lcom/hostdom/aircontrol/MainActivity$a$2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/hostdom/aircontrol/MainActivity$a;->printPage()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/hostdom/aircontrol/MainActivity$a;


# direct methods
.method constructor <init>(Lcom/hostdom/aircontrol/MainActivity$a;)V
    .locals 0

    iput-object p1, p0, Lcom/hostdom/aircontrol/MainActivity$a$2;->a:Lcom/hostdom/aircontrol/MainActivity$a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$a$2;->a:Lcom/hostdom/aircontrol/MainActivity$a;

    iget-object v0, v0, Lcom/hostdom/aircontrol/MainActivity$a;->b:Lcom/hostdom/aircontrol/MainActivity;

    iget-object v1, p0, Lcom/hostdom/aircontrol/MainActivity$a$2;->a:Lcom/hostdom/aircontrol/MainActivity$a;

    iget-object v1, v1, Lcom/hostdom/aircontrol/MainActivity$a;->b:Lcom/hostdom/aircontrol/MainActivity;

    iget-object v1, v1, Lcom/hostdom/aircontrol/MainActivity;->m:Landroid/webkit/WebView;

    invoke-virtual {v0, v1}, Lcom/hostdom/aircontrol/MainActivity;->a(Landroid/webkit/WebView;)V

    return-void
.end method
