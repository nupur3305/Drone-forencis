.class Lcom/hostdom/aircontrol/MainActivity$5;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/hostdom/aircontrol/MainActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Lcom/hostdom/aircontrol/MainActivity;


# direct methods
.method constructor <init>(Lcom/hostdom/aircontrol/MainActivity;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/hostdom/aircontrol/MainActivity$5;->b:Lcom/hostdom/aircontrol/MainActivity;

    iput-object p2, p0, Lcom/hostdom/aircontrol/MainActivity$5;->a:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$5;->b:Lcom/hostdom/aircontrol/MainActivity;

    iget-object v0, v0, Lcom/hostdom/aircontrol/MainActivity;->n:Landroid/widget/ImageView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$5;->b:Lcom/hostdom/aircontrol/MainActivity;

    iget-object v0, v0, Lcom/hostdom/aircontrol/MainActivity;->m:Landroid/webkit/WebView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setVisibility(I)V

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$5;->a:Ljava/lang/String;

    iget-object v1, p0, Lcom/hostdom/aircontrol/MainActivity$5;->b:Lcom/hostdom/aircontrol/MainActivity;

    invoke-static {v1}, Lcom/hostdom/aircontrol/MainActivity;->a(Lcom/hostdom/aircontrol/MainActivity;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/hostdom/aircontrol/MainActivity$5;->b:Lcom/hostdom/aircontrol/MainActivity;

    const-string v1, "This app is created using an unauthorized copy of \'Website 2 APK Builder Pro\' Software."

    const-string v2, "Unauthorized App"

    const-string v3, "Shame on me!"

    invoke-virtual {v0, v1, v2, v3}, Lcom/hostdom/aircontrol/MainActivity;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    return-void
.end method
