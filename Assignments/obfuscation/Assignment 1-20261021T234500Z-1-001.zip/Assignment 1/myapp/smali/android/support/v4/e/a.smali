.class public Landroid/support/v4/e/a;
.super Ljava/lang/Object;


# direct methods
.method public static a(III)I
    .locals 0

    if-ge p0, p1, :cond_0

    return p1

    :cond_0
    if-le p0, p2, :cond_1

    return p2

    :cond_1
    return p0
.end method
