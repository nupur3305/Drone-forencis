.class public final Landroid/support/design/a$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/design/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# static fields
.field public static final abc_action_bar_content_inset_material:I = 0x7f060000

.field public static final abc_action_bar_content_inset_with_nav:I = 0x7f060001

.field public static final abc_action_bar_default_height_material:I = 0x7f060002

.field public static final abc_action_bar_default_padding_end_material:I = 0x7f060003

.field public static final abc_action_bar_default_padding_start_material:I = 0x7f060004

.field public static final abc_action_bar_elevation_material:I = 0x7f060005

.field public static final abc_action_bar_icon_vertical_padding_material:I = 0x7f060006

.field public static final abc_action_bar_overflow_padding_end_material:I = 0x7f060007

.field public static final abc_action_bar_overflow_padding_start_material:I = 0x7f060008

.field public static final abc_action_bar_progress_bar_size:I = 0x7f060009

.field public static final abc_action_bar_stacked_max_height:I = 0x7f06000a

.field public static final abc_action_bar_stacked_tab_max_width:I = 0x7f06000b

.field public static final abc_action_bar_subtitle_bottom_margin_material:I = 0x7f06000c

.field public static final abc_action_bar_subtitle_top_margin_material:I = 0x7f06000d

.field public static final abc_action_button_min_height_material:I = 0x7f06000e

.field public static final abc_action_button_min_width_material:I = 0x7f06000f

.field public static final abc_action_button_min_width_overflow_material:I = 0x7f060010

.field public static final abc_alert_dialog_button_bar_height:I = 0x7f060011

.field public static final abc_button_inset_horizontal_material:I = 0x7f060012

.field public static final abc_button_inset_vertical_material:I = 0x7f060013

.field public static final abc_button_padding_horizontal_material:I = 0x7f060014

.field public static final abc_button_padding_vertical_material:I = 0x7f060015

.field public static final abc_cascading_menus_min_smallest_width:I = 0x7f060016

.field public static final abc_config_prefDialogWidth:I = 0x7f060017

.field public static final abc_control_corner_material:I = 0x7f060018

.field public static final abc_control_inset_material:I = 0x7f060019

.field public static final abc_control_padding_material:I = 0x7f06001a

.field public static final abc_dialog_fixed_height_major:I = 0x7f06001b

.field public static final abc_dialog_fixed_height_minor:I = 0x7f06001c

.field public static final abc_dialog_fixed_width_major:I = 0x7f06001d

.field public static final abc_dialog_fixed_width_minor:I = 0x7f06001e

.field public static final abc_dialog_list_padding_bottom_no_buttons:I = 0x7f06001f

.field public static final abc_dialog_list_padding_top_no_title:I = 0x7f060020

.field public static final abc_dialog_min_width_major:I = 0x7f060021

.field public static final abc_dialog_min_width_minor:I = 0x7f060022

.field public static final abc_dialog_padding_material:I = 0x7f060023

.field public static final abc_dialog_padding_top_material:I = 0x7f060024

.field public static final abc_dialog_title_divider_material:I = 0x7f060025

.field public static final abc_disabled_alpha_material_dark:I = 0x7f060026

.field public static final abc_disabled_alpha_material_light:I = 0x7f060027

.field public static final abc_dropdownitem_icon_width:I = 0x7f060028

.field public static final abc_dropdownitem_text_padding_left:I = 0x7f060029

.field public static final abc_dropdownitem_text_padding_right:I = 0x7f06002a

.field public static final abc_edit_text_inset_bottom_material:I = 0x7f06002b

.field public static final abc_edit_text_inset_horizontal_material:I = 0x7f06002c

.field public static final abc_edit_text_inset_top_material:I = 0x7f06002d

.field public static final abc_floating_window_z:I = 0x7f06002e

.field public static final abc_list_item_padding_horizontal_material:I = 0x7f06002f

.field public static final abc_panel_menu_list_width:I = 0x7f060030

.field public static final abc_progress_bar_height_material:I = 0x7f060031

.field public static final abc_search_view_preferred_height:I = 0x7f060032

.field public static final abc_search_view_preferred_width:I = 0x7f060033

.field public static final abc_seekbar_track_background_height_material:I = 0x7f060034

.field public static final abc_seekbar_track_progress_height_material:I = 0x7f060035

.field public static final abc_select_dialog_padding_start_material:I = 0x7f060036

.field public static final abc_switch_padding:I = 0x7f060037

.field public static final abc_text_size_body_1_material:I = 0x7f060038

.field public static final abc_text_size_body_2_material:I = 0x7f060039

.field public static final abc_text_size_button_material:I = 0x7f06003a

.field public static final abc_text_size_caption_material:I = 0x7f06003b

.field public static final abc_text_size_display_1_material:I = 0x7f06003c

.field public static final abc_text_size_display_2_material:I = 0x7f06003d

.field public static final abc_text_size_display_3_material:I = 0x7f06003e

.field public static final abc_text_size_display_4_material:I = 0x7f06003f

.field public static final abc_text_size_headline_material:I = 0x7f060040

.field public static final abc_text_size_large_material:I = 0x7f060041

.field public static final abc_text_size_medium_material:I = 0x7f060042

.field public static final abc_text_size_menu_header_material:I = 0x7f060043

.field public static final abc_text_size_menu_material:I = 0x7f060044

.field public static final abc_text_size_small_material:I = 0x7f060045

.field public static final abc_text_size_subhead_material:I = 0x7f060046

.field public static final abc_text_size_subtitle_material_toolbar:I = 0x7f060047

.field public static final abc_text_size_title_material:I = 0x7f060048

.field public static final abc_text_size_title_material_toolbar:I = 0x7f060049

.field public static final compat_button_inset_horizontal_material:I = 0x7f06004c

.field public static final compat_button_inset_vertical_material:I = 0x7f06004d

.field public static final compat_button_padding_horizontal_material:I = 0x7f06004e

.field public static final compat_button_padding_vertical_material:I = 0x7f06004f

.field public static final compat_control_corner_material:I = 0x7f060050

.field public static final design_appbar_elevation:I = 0x7f060051

.field public static final design_bottom_navigation_active_item_max_width:I = 0x7f060052

.field public static final design_bottom_navigation_active_text_size:I = 0x7f060053

.field public static final design_bottom_navigation_elevation:I = 0x7f060054

.field public static final design_bottom_navigation_height:I = 0x7f060055

.field public static final design_bottom_navigation_item_max_width:I = 0x7f060056

.field public static final design_bottom_navigation_item_min_width:I = 0x7f060057

.field public static final design_bottom_navigation_margin:I = 0x7f060058

.field public static final design_bottom_navigation_shadow_height:I = 0x7f060059

.field public static final design_bottom_navigation_text_size:I = 0x7f06005a

.field public static final design_bottom_sheet_modal_elevation:I = 0x7f06005b

.field public static final design_bottom_sheet_peek_height_min:I = 0x7f06005c

.field public static final design_fab_border_width:I = 0x7f06005d

.field public static final design_fab_elevation:I = 0x7f06005e

.field public static final design_fab_image_size:I = 0x7f06005f

.field public static final design_fab_size_mini:I = 0x7f060060

.field public static final design_fab_size_normal:I = 0x7f060061

.field public static final design_fab_translation_z_pressed:I = 0x7f060062

.field public static final design_navigation_elevation:I = 0x7f060063

.field public static final design_navigation_icon_padding:I = 0x7f060064

.field public static final design_navigation_icon_size:I = 0x7f060065

.field public static final design_navigation_max_width:I = 0x7f060066

.field public static final design_navigation_padding_bottom:I = 0x7f060067

.field public static final design_navigation_separator_vertical_padding:I = 0x7f060068

.field public static final design_snackbar_action_inline_max_width:I = 0x7f060069

.field public static final design_snackbar_background_corner_radius:I = 0x7f06006a

.field public static final design_snackbar_elevation:I = 0x7f06006b

.field public static final design_snackbar_extra_spacing_horizontal:I = 0x7f06006c

.field public static final design_snackbar_max_width:I = 0x7f06006d

.field public static final design_snackbar_min_width:I = 0x7f06006e

.field public static final design_snackbar_padding_horizontal:I = 0x7f06006f

.field public static final design_snackbar_padding_vertical:I = 0x7f060070

.field public static final design_snackbar_padding_vertical_2lines:I = 0x7f060071

.field public static final design_snackbar_text_size:I = 0x7f060072

.field public static final design_tab_max_width:I = 0x7f060073

.field public static final design_tab_scrollable_min_width:I = 0x7f060074

.field public static final design_tab_text_size:I = 0x7f060075

.field public static final design_tab_text_size_2line:I = 0x7f060076

.field public static final disabled_alpha_material_dark:I = 0x7f060077

.field public static final disabled_alpha_material_light:I = 0x7f060078

.field public static final fastscroll_default_thickness:I = 0x7f060079

.field public static final fastscroll_margin:I = 0x7f06007a

.field public static final fastscroll_minimum_range:I = 0x7f06007b

.field public static final highlight_alpha_material_colored:I = 0x7f06007c

.field public static final highlight_alpha_material_dark:I = 0x7f06007d

.field public static final highlight_alpha_material_light:I = 0x7f06007e

.field public static final hint_alpha_material_dark:I = 0x7f06007f

.field public static final hint_alpha_material_light:I = 0x7f060080

.field public static final hint_pressed_alpha_material_dark:I = 0x7f060081

.field public static final hint_pressed_alpha_material_light:I = 0x7f060082

.field public static final item_touch_helper_max_drag_scroll_per_frame:I = 0x7f060083

.field public static final item_touch_helper_swipe_escape_max_velocity:I = 0x7f060084

.field public static final item_touch_helper_swipe_escape_velocity:I = 0x7f060085

.field public static final notification_action_icon_size:I = 0x7f060086

.field public static final notification_action_text_size:I = 0x7f060087

.field public static final notification_big_circle_margin:I = 0x7f060088

.field public static final notification_content_margin_start:I = 0x7f060089

.field public static final notification_large_icon_height:I = 0x7f06008a

.field public static final notification_large_icon_width:I = 0x7f06008b

.field public static final notification_main_column_padding_top:I = 0x7f06008c

.field public static final notification_media_narrow_margin:I = 0x7f06008d

.field public static final notification_right_icon_size:I = 0x7f06008e

.field public static final notification_right_side_padding_top:I = 0x7f06008f

.field public static final notification_small_icon_background_padding:I = 0x7f060090

.field public static final notification_small_icon_size_as_large:I = 0x7f060091

.field public static final notification_subtext_size:I = 0x7f060092

.field public static final notification_top_pad:I = 0x7f060093

.field public static final notification_top_pad_large_text:I = 0x7f060094

.field public static final tooltip_corner_radius:I = 0x7f060095

.field public static final tooltip_horizontal_padding:I = 0x7f060096

.field public static final tooltip_margin:I = 0x7f060097

.field public static final tooltip_precise_anchor_extra_offset:I = 0x7f060098

.field public static final tooltip_precise_anchor_threshold:I = 0x7f060099

.field public static final tooltip_vertical_padding:I = 0x7f06009a

.field public static final tooltip_y_offset_non_touch:I = 0x7f06009b

.field public static final tooltip_y_offset_touch:I = 0x7f06009c
